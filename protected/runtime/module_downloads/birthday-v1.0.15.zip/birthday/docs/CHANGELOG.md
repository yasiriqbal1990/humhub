Changelog
=========

1.0.15 - April 14, 2022
-----------------------
- Fix #25: Fix tests
- Enh #4823: Remove CHTML/CActiveForm usages


1.0.14 - June 14, 2019
------------------------
- Enh: Updated translations
- Enh: Improved module docs


1.0.13 - January 2, 2018
------------------------
- Fix: Removed day string from time calculation


1.0.12 - January 2, 2018
------------------------
- Enh: Add configuration option to exclude group (@enguerrand)
- Enh: Collapsible widget (@Felli)
- Fix #14: Incorrect turn of year handling (@enguerrand)


1.0.11 - October 9, 2017
------------------------
- Fix: Incorrect order on many birthdays at the same time range
