<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '',
  'Back to modules' => '',
  'Birthday Module Configuration' => '',
  'In {days} days' => '',
  'Save' => 'አስቀምጥ',
  'The group id of the group that should be exluded.' => '',
  'The number of days future birthdays will be shown within.' => '',
  'Tomorrow' => '',
  'You may configure the number of days within the upcoming birthdays are shown.' => '',
  'becomes {years} years old.' => '',
  'today' => '',
);
