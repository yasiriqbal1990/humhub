<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Рождени дни</strong> в рамките на следващите {days} дни',
  'Back to modules' => 'Върни се при модулите',
  'Birthday Module Configuration' => 'Конфигурация на модула за рожден ден',
  'In {days} days' => 'След {days} дни',
  'Save' => 'Запази',
  'The group id of the group that should be exluded.' => 'Идентификационният номер на групата, който трябва да бъде изключен.',
  'The number of days future birthdays will be shown within.' => 'Броят на бъдещите рождени дни ще бъде показан в рамките на.',
  'Tomorrow' => 'Утре',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Можете да конфигурирате броя дни, в рамките на които предстоящите рождени дни се показват.',
  'becomes {years} years old.' => 'става на {years} години.',
  'today' => 'днес',
);
