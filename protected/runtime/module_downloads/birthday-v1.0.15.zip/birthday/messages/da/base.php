<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Fødselsdage</strong> inden for de næste {days} dage',
  'Back to modules' => 'Tilbage til moduler',
  'Birthday Module Configuration' => 'Fødselsdag Modul konfiguration',
  'In {days} days' => 'Om {days} dage',
  'Save' => 'Gem',
  'The group id of the group that should be exluded.' => 'ID\'et for den gruppe som skal ekskluderes.',
  'The number of days future birthdays will be shown within.' => 'Hvor mange dage ud i fremtiden fødselsdage vises.',
  'Tomorrow' => 'Imorgen',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Du kan indstille, antallet af dage som vises  i kommende fødselsdage.',
  'becomes {years} years old.' => 'fylder {years} år.',
  'today' => 'i dag',
);
