<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Γενέθλια</strong> στις επόμενες {ημέρες} ημέρες',
  'Back to modules' => 'Επιστροφή στις μονάδες',
  'Birthday Module Configuration' => 'Διαμόρφωση μονάδας γενεθλίων',
  'In {days} days' => 'Σε {days} ημέρες',
  'Save' => 'Αποθήκευση',
  'The group id of the group that should be exluded.' => 'Η αναγνωριστική ταυτότητα της ομάδας που πρέπει να αποκλειστεί.',
  'The number of days future birthdays will be shown within.' => 'Ο αριθμός ημερών των μελλοντικών γενεθλίων θα εμφανιστεί μέσα.',
  'Tomorrow' => 'Αύριο',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Μπορείτε να ρυθμίσετε τον αριθμό των ημερών που εμφανίζονται στα επερχόμενα γενέθλια.',
  'becomes {years} years old.' => 'γίνεται {years} ετών.',
  'today' => 'σήμερα',
);
