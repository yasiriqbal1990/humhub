<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Compleanni</strong> nei prossimi {days} giorni',
  'Back to modules' => 'Torna ai moduli',
  'Birthday Module Configuration' => 'Configurazioni Modulo Compleanno',
  'In {days} days' => 'In {days} giorni',
  'Save' => 'Salva',
  'The group id of the group that should be exluded.' => 'l\'id del gruppo che verrebbe escluso.',
  'The number of days future birthdays will be shown within.' => 'Numero di giorni per i futuri compleanni che verrà mostrato.',
  'Tomorrow' => 'Domani',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Puoi configurare il numero di giorni entro il quale mostrare i prossimi compleanni in arrivo.',
  'becomes {years} years old.' => 'Compie {years} anni!',
  'today' => 'oggi',
);
