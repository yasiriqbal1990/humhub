<?php

namespace tests\codeception\unit\modules\birthday;

use tests\codeception\_support\HumHubDbTestCase;

class BirthdayTest extends HumHubDbTestCase
{
}
