<?php
/**
 * Initialize the HumHub Application for functional testing. The default application configuration for this suite can be overwritten
 * in @tests/config/functional.php
 */
require(Yii::getAlias('@humhubTests/codeception/unit/_bootstrap.php'));